# Freebuff Ultimate Skills

A practical collection of agent skills for creative workflows, 3D printing, coding, research, and troubleshooting.

## Install

Install all skills (if your agent supports the `skills` installer):

```bash
npx skills add GBS-2805/freebuff-ultimate-skills --skill "*" --yes
```

Install one skill:

```bash
npx skills add GBS-2805/freebuff-ultimate-skills --skill blender-product-rendering
```

## Included skills

- `blender-product-rendering`
- `creality-k1-se`
- `orcaslicer-tuning`
- `ui-design`
- `coding-workflow`
- `research-and-writing`
- `github-workflow`
- `technical-troubleshooting`

Check your agent's documentation for supported skill discovery and installation formats.
