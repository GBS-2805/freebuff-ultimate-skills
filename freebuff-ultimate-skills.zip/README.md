# Freebuff Ultimate Skills

An Agent Skills pack for Freebuff and compatible agents.

## Install all skills
```bash
npx skills add GBS-2805/freebuff-ultimate-skills --skill "*" --yes
```

## Install one skill
```bash
npx skills add GBS-2805/freebuff-ultimate-skills --skill blender-product-rendering --yes
```

If prompted, choose Freebuff or the universal/agent-agnostic target. Choose user-level installation for use across projects.

## Skills
- `blender-product-rendering` — keyboard/product renders, UVs, materials, HDRIs, project handoff.
- `creality-k1-se` — K1 SE setup, maintenance, calibration, and print diagnosis.
- `orcaslicer-tuning` — supports, stringing, extrusion, first layers, material profiles.
- `ui-design` — UX flows, interface critique, accessibility, responsive specs.
- `coding-workflow` — safe code changes, testing, debugging.
- `research-and-writing` — source evaluation, synthesis, citations, clear academic writing.
- `github-workflow` — repositories, branches, commits, issues, pull requests.
- `technical-troubleshooting` — evidence-driven diagnosis across software and hardware.

Each skill is a folder containing `SKILL.md`. Skills provide workflows, not proof an action was completed. Never claim settings, files, hardware, or repositories were changed unless a tool confirms it.

## Layout
```text
skills/<skill-name>/SKILL.md
AGENTS.md
LICENSE
```

Keep skills focused and actionable. Verify version-sensitive procedures against current official documentation.
