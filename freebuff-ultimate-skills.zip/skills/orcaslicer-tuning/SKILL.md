---
name: orcaslicer-tuning
description: Tune OrcaSlicer profiles and diagnose supports, stringing, extrusion, first layers, and material-specific FDM print behavior.
---
# OrcaSlicer tuning

## Intake
Record printer/firmware, OrcaSlicer version, nozzle diameter, plate, filament brand/exact variant, drying status, and filament/printer/process profiles. Request the 3MF when exact settings matter; one settings screenshot is not a complete profile.

## Sequence
1. Duplicate the current profile.
2. Locate the defect: first layer, walls, top surface, travel, overhang, or support interface.
3. Check mechanical and material causes before slicer compensation.
4. Choose one targeted calibration/test.
5. Change one variable at a time and compare with baseline.

## Supports fused to model
Check support type/placement, paint-on supports or blockers, top/bottom Z distances, interface layers/density/pattern, XY separation, cooling, temperature, and overhang geometry. A larger Z gap may ease removal but worsen the underside. There is no universal value: layer height, nozzle, material, orientation, and interface design matter. Test a small representative overhang.

## Stringing
Check moisture, nozzle temperature, travel distance, retraction, wipe behavior, idle ooze, and nozzle contamination. Dry per manufacturer guidance. Do not blindly increase retraction; too much can cause heat-creep or inconsistent extrusion.

## Extrusion clues
Over-extrusion: raised ridges, rough top skin, bulging corners, nozzle drag. Under-extrusion: gaps, thin walls, missing segments, weak bonding. Verify filament diameter, nozzle condition, temperature, flow ratio, max volumetric speed, and extrusion calibration. Avoid changing flow ratio and pressure advance together.

Keep filament, printer, and process profiles distinct. Preserve stock profiles. Validate changes with a small print. Report likely causes, exact setting names/locations, a conservative test, and what result confirms or rejects the hypothesis. Never claim a profile was edited unless it was.
