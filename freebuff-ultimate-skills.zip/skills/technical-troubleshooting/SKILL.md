---
name: technical-troubleshooting
description: Diagnose technical problems across software, hardware, creative tools, and workflows using evidence-driven tests and reversible changes.
---
# Technical troubleshooting

1. Define symptom, expected behavior, start time, and frequency.
2. Establish scope: one file, device, app, project, or all projects?
3. Collect exact errors, screenshots, logs, versions, recent changes, and a minimal reproduction.
4. Rank hypotheses by evidence.
5. Choose the smallest reversible test that distinguishes them.
6. Record changes and results.
7. Verify the original task and document prevention/recovery.

Change one variable at a time. Preserve backups and known-good settings. Prefer official version-specific documentation. Avoid destructive resets until safer options are exhausted. Explain uncertainty.

Response structure: evidence-based likely cause, first check, one safe test, meaning of each result, and what information would narrow diagnosis. Do not claim fixed unless confirmed.
