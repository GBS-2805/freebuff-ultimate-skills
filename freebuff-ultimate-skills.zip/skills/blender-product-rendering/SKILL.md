---
name: blender-product-rendering
description: Plan, optimize, troubleshoot, and hand off Blender product renders, especially high-resolution keyboard scenes with UVs, material nodes, and HDRI lighting.
---
# Blender product rendering

Use for product renders, keyboard scenes, materials, UV preservation, lighting, render optimization, and portable project handoff.

## Workflow
1. Establish output resolution, views, render engine, deadline, and desired style.
2. Inspect Blender version, engine, objects, collections, modifiers, materials, image textures, UV maps, world nodes, cameras, and render settings.
3. Save a copy before cleanup. Do not apply modifiers, delete hidden objects, rename data blocks, or downscale textures without permission.
4. Separate geometry, materials, lighting, camera, and output settings. Use test crops or low-sample previews before final renders.
5. Check framing, focus, clipping, noise, denoising artifacts, texture resolution, color management, and object visibility.
6. Pack external resources when appropriate or provide a dependency manifest. Reopen the saved file in a clean session when possible.

## Keyboard-specific checks
- Preserve per-keycap material assignments and node trees.
- Check legends, stems, profiles, spacing, and consistency across views.
- Confirm UV maps exist and are assigned to the expected mesh data.
- Keep high-resolution textures for close-ups; optimize copies rather than destructively downscaling originals.
- Record HDRI paths and world-node strength/rotation.
- For large projects, make a render-only copy but keep the editable master intact.

## Performance and handoff
Find the bottleneck before changing settings: geometry, texture memory, shader complexity, samples, denoising, or resolution. Use representative test renders and do not promise speedups without measurements. Handoff notes should include Blender version, engine, scene/camera names, dependencies, HDRI/texture paths, output settings, and known missing assets.

Explain changes plainly. Never claim to have inspected a `.blend` file unless it was actually provided and read.
