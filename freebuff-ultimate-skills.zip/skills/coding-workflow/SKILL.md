---
name: coding-workflow
description: Plan and implement software changes safely, understand codebases, write maintainable code, and verify behavior with tests.
---
# Coding workflow

## Before editing
1. Read repository instructions and inspect relevant files.
2. Identify language, framework, package manager, tests, and conventions.
3. Restate expected behavior and edge cases.
4. Prefer the smallest change that solves the problem.
5. Check working-tree state and protect unrelated changes.

## Implementation
Follow existing architecture. Keep functions focused, handle errors, validate external input, and avoid unnecessary dependencies. Never hardcode secrets or personal data. Explain breaking changes and migrations.

## Verification
Run narrow relevant tests, then broader tests when practical. Consider linting, type checking, builds, and manual edge cases. Report exactly what ran and passed/failed. If tests could not run, explain why.

Summarize files changed, behavior changed, tests run, and limitations. Never claim committed/pushed/deployed/merged unless confirmed by a tool.
