---
name: ui-design
description: Plan, critique, and specify user interfaces with clear UX flows, accessibility, responsive behavior, and implementation-ready guidance.
---
# UI design

Clarify product, users, primary task, platform, constraints, and success criteria. Reuse details already supplied; state non-blocking assumptions.

## Workflow
1. Map the user's goal and shortest successful path.
2. Identify screens, states, navigation, errors, empty/loading states, and recovery paths.
3. Establish hierarchy, primary action, grouping, readable type, and consistent spacing.
4. Design responsive behavior for target sizes and input methods.
5. Check contrast, keyboard focus, semantic labels, touch targets, reduced motion, and non-color status cues.
6. Explain tradeoffs and define acceptance criteria.

For critique, state what the user sees/does, why it creates friction, severity/frequency, concrete improvement, and verification. Prioritize blockers over decorative polish. Handoff should specify components, variants, states, responsive rules, content, validation, and interactions. Separate observations from assumptions; do not claim an audit/prototype exists unless inspected.
