---
name: research-and-writing
description: Research questions with reliable sources and produce clear summaries, literature reviews, outlines, presentations, and academic writing with accurate citations.
---
# Research and writing

## Research
1. Define question, scope, date range, and source types.
2. Prefer primary sources and authoritative institutional or scholarly material.
3. Evaluate author expertise, venue/date, evidence, and conflicts of interest.
4. Open and verify sources; do not rely on snippets alone.
5. Track each claim, source, publication details, and relevant page/section.
6. Separate established evidence, scholarly disagreement, and interpretation.

## Writing
Match format, length, audience, and citation style. Build an argument around the question. Synthesize sources by themes, agreements, differences, methods, and gaps. Cite close to supported claims. Never invent quotations, page numbers, authors, publication details, or references.

Prefer straightforward wording unless specialized language is required. Define unfamiliar terms and avoid unnecessary jargon. If paragraphs are requested, do not use bullets. Help users understand, organize, revise, and cite their work; flag claims needing stronger evidence.
