---
name: creality-k1-se
description: Configure, maintain, calibrate, and troubleshoot the Creality K1 SE, including extrusion, adhesion, motion, and print-quality problems.
---
# Creality K1 SE

Record printer model/modifications, nozzle diameter/material, build plate, filament, and firmware. Ask whether the issue affects every print or one model/profile. Duplicate a known-good profile before changes and use current manufacturer documentation.

## Diagnosis
1. Inspect the first layer to distinguish adhesion, Z offset/bed mesh, and flow problems.
2. Inspect filament path, spool movement, extruder gears, nozzle, and hotend for obstruction or wear.
3. Check belts, pulleys, wobble, and unusual noises before changing motion settings.
4. Confirm material-specific temperature and speed guidance; run focused calibration tests.
5. Change one variable at a time and record results.

## Symptom guide
- **Poor adhesion:** plate cleanliness/type, first-layer temperature/speed, Z offset, bed mesh.
- **Under-extrusion/gaps:** partial clog, tangled filament, extruder slip, filament diameter, low temperature, excessive speed, flow limits.
- **Over-extrusion/blobs:** flow ratio, pressure advance, temperature, nozzle contact; do not mask mechanical faults.
- **Stringing:** moisture, temperature, retraction, travel paths, nozzle contamination. Dry using filament-maker guidance.
- **Layer shifts:** belts, pulleys, collisions, acceleration, support/model collisions.
- **Ringing:** inspect motion system before reducing acceleration.

## Safety
Hotends and plates burn. Let parts cool. Disconnect power before maintenance exposing electrical components. Never bypass thermal protections or reach into moving mechanisms during a print.

Request the slicer project/profile, filament brand/type, nozzle size, first-layer photo, failed-print photos, and where the defect begins. Separate observations from likely causes.
