# Agent guidance
- Read the matching skill's `SKILL.md` before beginning a covered task.
- Treat skill instructions as workflows, not evidence an action happened.
- Ask for missing constraints only when they materially affect correctness.
- Inspect files and settings before editing; prefer reversible changes.
- Verify version-sensitive details against current official documentation.
- Never invent measurements, sources, citations, paths, test results, or successful actions.
- For 3D printing, preserve a known-good baseline and change one variable at a time.
- For research, separate sourced facts from interpretation and cite claims close to the text.
- For code, explain risky changes and run relevant tests when available.
